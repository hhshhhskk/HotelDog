import React from "react";

const UserPage = () => {
  return <h1>일반회원</h1>;
};

export default UserPage;
