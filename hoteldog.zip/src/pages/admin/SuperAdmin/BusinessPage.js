import React from "react";

const BusinessPage = () => {
  return <h1>BusinessPage</h1>;
};

export default BusinessPage;
