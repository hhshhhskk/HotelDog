import React from "react";

const BusinessReq = () => {
  return <h1>BusinessReq</h1>;
};

export default BusinessReq;
