import styled from "@emotion/styled";
import React from "react";

const MemberPage = styled.div`
  position: relative;
`;

const Member = () => {
  return (
    <MemberPage>
      <p>회원정보</p>
    </MemberPage>
  );
};

export default Member;
