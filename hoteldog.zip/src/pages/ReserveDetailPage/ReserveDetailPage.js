import React from "react";

// 호텔 예약 상세페이지
const ReserveDetailPage = () => {
  return <div>ReserveDetailPage</div>;
};

export default ReserveDetailPage;
