import React from "react";

// 행사 페이지
const EventPage = () => {
  return <div>EventPage</div>;
};

export default EventPage;
