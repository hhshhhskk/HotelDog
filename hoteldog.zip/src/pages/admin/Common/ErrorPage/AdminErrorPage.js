import React from "react";

const AdminErrorPage = () => {
  return <div>AdminErrorPage!</div>;
};

export default AdminErrorPage;
